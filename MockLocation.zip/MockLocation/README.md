Mock Location Android project. Build with GitHub Actions (see chat instructions).
